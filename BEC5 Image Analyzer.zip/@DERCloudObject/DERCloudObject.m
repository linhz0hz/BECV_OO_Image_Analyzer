classdef DERCloudObject < CloudImageObject
    
    methods
        
    function obj = DERCloudObject(x)
        {
             
%             Cloud Image Object constructor called:
               obj@CloudImageObject('magnification',0.25);
            
        }
    end
    
    end
end
